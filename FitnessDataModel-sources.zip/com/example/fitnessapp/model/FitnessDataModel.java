
package com.example.fitnessapp.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class FitnessDataModel {

    public String category;
    public String difficulty;
    public String force;
    public String grips;
    public String exerciseName;
    public Integer id;
    public List<String> steps;
    public Target target;
    public List<String> videoURL;
    public String youtubeURL;
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
